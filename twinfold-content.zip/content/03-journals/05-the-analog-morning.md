# The Analog Morning: A Screen-Free First Hour

**SEO title:** The Analog Morning: How to Start Screen-Free
**Meta description:** A calm, practical guide to a screen-free morning — build a phone-free first hour that trades doomscrolling for a slower, more intentional analog ritual.
**Primary keywords:** screen-free morning, phone-free routine, analog morning, morning ritual

A screen-free morning is not a productivity hack. It is a small act of self-respect. For most of us the day now begins with a bright rectangle held six inches from our face — notifications, headlines, other people's plans for our attention — before we have taken a single conscious breath. A phone-free routine simply moves that moment later, and in the gap it opens, something quieter has room to happen.

This is the heart of the analog revival that so many people have leaned into over the last couple of years. Not a rejection of technology, but a gentle boundary around it. If the last decade taught us to be reachable at all times, this one is teaching us that the first hour of the day might belong to us. What follows is a warm, doable guide to reclaiming it — no rigid rules, no 5am cold plunges, no guilt. Intention over perfection.

## Why the first hour matters

The first hour sets the emotional weather for everything after it. Reach for the phone and you inherit its pace: fast, fragmented, faintly anxious. You are reacting before you are even awake. A screen-free morning does the opposite. It lets you arrive in your own day slowly, on your own terms, thinking your own thoughts before the world offers you a thousand of its own.

There is nothing precious about this. You do not need an aesthetic kitchen or an hour to spare. You need one decision — that the phone can wait — and a few analog anchors to fill the space it leaves behind. The point is not to perform a perfect morning. It is to notice, for sixty unhurried minutes, that you are a person and not an inbox.

## A gentle framework, not a formula

Think of the analog morning as three soft movements rather than a checklist: **wake without input, make something slowly, and put a few words on paper.** Take one, take all three, adapt as your life demands. A morning ritual only works if it survives a bad night's sleep and a busy Tuesday.

### 1. Leave the phone charging in another room

This is the single change that makes everything else possible, and it is almost embarrassingly effective. Charge your phone overnight in the kitchen or the hallway — anywhere that is not arm's reach of the bed. Buy a small alarm clock so you are no longer using the phone as your wake-up excuse to check it.

You will feel the pull on the first morning, a phantom reach toward a bedside table that no longer holds anything. By the third or fourth day, the quiet stops feeling like absence and starts feeling like room. You are not banning the phone. You are just not letting it be the first voice you hear.

### 2. Make something slowly

Give your hands a small, warm task while your mind is still soft. For a lot of people that is coffee — not the fastest cup, but a deliberate one. Grinding beans, waiting for the kettle to settle off the boil, watching the bloom rise in a pour-over: this is analog time distilled. It asks for your attention and gives back a few minutes of calm before anything is required of you.

If you take your coffee seriously, a considered bag of beans turns the ritual into something you look forward to the night before. Our [Brew & Sip](/collections/brew-and-sip) edit is built for exactly this kind of slow start — including the properly good [Girls Who Grind — Girl Crush Espresso](/products/girls-who-grind-girl-crush-espresso-blend), roasted by a brilliant independent. Tea drinkers, the invitation is the same: warm the pot, don't rush the steep. The drink is almost beside the point. The making is the ritual.

### 3. Write three lines by hand

Before you consult a single screen, put a pen to paper. Not a novel — three lines. What is on your mind. One thing you are looking forward to. One thing that would make today feel complete. That is the whole exercise.

Writing by hand is slower than typing, and that slowness is the feature. It forces you to choose your words, and in choosing them you find out what you actually think. There is good evidence that handwriting engages the brain differently from tapping a keyboard, but you do not need the research to feel it — a few honest sentences in the morning quietly clears the mental clutter that scrolling only adds to.

Keep the tools simple and to hand: a notebook you like the feel of and a pen that glides. A page that lies flat makes the habit easier, which is partly why we made the [Moor Layflat Notebook](/products/moor-layflat-notebook) — it stays open on the table so nothing gets in the way of the thought. Explore the rest of the [Desk & Paper](/collections/desk-and-paper) range if you want a small, considered set of things to think with. But truthfully, any paper you will actually reach for is the right paper. The habit matters more than the object.

## Filling the rest of the hour

Once the phone is elsewhere and the pen is moving, the remaining minutes tend to look after themselves. Read a few pages of a real book. Stand at the window with your coffee and do nothing in particular. Stretch. Step outside for two minutes of morning light, which does more for your energy than any notification ever will. Let a little boredom in — it is where quieter, more original thoughts tend to surface.

The aim is not to fill the hour with more tasks. It is to prove to yourself that the day can begin gently, without input, and still go perfectly well. Most mornings, it goes better.

## Start small, and start tomorrow

You do not need to overhaul your life to feel the difference. Choose one movement — most people start by simply moving the charger to another room — and let it settle before adding another. A phone-free routine is not about discipline or denial. It is about deciding that your attention is worth protecting, and that the first hour of the day is a fine place to begin.

If you would like a few well-made analog companions for the ritual — something to write in, something good to brew — our [Desk & Paper](/collections/desk-and-paper) and [Brew & Sip](/collections/brew-and-sip) collections are quietly built for mornings exactly like this. No rush. The screens will still be there at nine. You just don't have to meet them first.
