# Buy Less, Keep Longer: A Small Guide to Considered Stationery & Sustainability

**SEO title:** Buy Less, Keep Longer: Considered Stationery Guide
**Meta description:** A calm guide to sustainable stationery and considered desk objects — what "eco" really means here, and how buying less but keeping longer changes your desk.
**Primary keywords:** sustainable stationery, considered stationery, eco desk, buy less keep longer, recycled notebook

There is a quiet shift happening on desks across the country. After years of screens, more of us are reaching for paper again — a notebook to think in, a good pen with weight to it, a single object that stays put rather than a drawer of things we half-remember buying. This is the analog revival, and underneath it sits a bigger idea about how we buy at all: fewer, better, longer. This is a short guide to what sustainable stationery actually means when you take the slogans away — and why considered stationery is less about owning less, and more about owning things worth keeping.

## What "considered" actually means

Considered is an easy word to overuse, so it's worth being specific. For us it means a range built as a system, not a shelf. Every piece has to earn its place: a durable hero object at the centre, and a small circle of consumables — papers, refills — that keep it in use for years. Nothing is there to pad out a catalogue.

It also means restraint at the point of design. A layflat notebook that opens flat so you actually write across the spine. A pen holder that holds what you use and no more. When a thing is designed to do one job well and last, you stop replacing it — and that, quietly, is the most sustainable decision of all. You can see the logic run through the whole [Desk & Paper](/collections/desk-and-paper) collection: a few things, chosen with care, meant to stay.

## Buy less, keep longer — the whole philosophy in four words

Most of what gets sold as "eco" is still built on the same engine: buy, discard, buy again, only now in a greener wrapper. Buying less and keeping longer breaks that loop at the source. A desk object you use every day for five years has a far smaller footprint than five cheaper ones bought and binned across the same span — regardless of what any of them were made from.

So the question we'd gently pose isn't *"is this recyclable?"* but *"will I still want this in three years?"* Durability is the first sustainability feature. Everything else follows from it. It's also why our range spans a real tier — from a small, low-commitment first purchase to a premium piece you might be given as a gift — so you can enter the system wherever you are and grow into it, rather than starting over each time.

## The materials, honestly

Here is where a lot of brands get vague, so we'll be plain about what our things are made from — and only where it's true.

Our notebooks are made from **recycled coffee-cup paper and repurposed waste** — material that would otherwise have been discarded, folded back into something you'll fill with your best thinking. That's the brand idea made literal: two leaves from one fold, one origin and two lives, waste turned back into worth. The [Moor Layflat Notebook](/products/moor-layflat-notebook) is a good place to feel it — the paper has a character to it, because of where it came from, not in spite of it.

Our desk objects are pressed from a **bio-composite wood**: recycled European wood fibres bound with a corn-derived, plant-based binder, and made in a workshop in France. It's a genuinely different material — warmer and more tactile than moulded alternatives, with a density that makes an object feel like it will outlast its owner's phone several times over. The [Stockholm Pen Holder](/products/stockholm-pen-holder) is the clearest example: a single, solid thing that sits on a desk and simply stays useful. You'll find more of these across [Objects](/collections/objects).

What we won't do is dress those facts up with claims we can't stand behind. We won't invent certifications or throw around numbers we haven't measured. Recycled content, real longevity, refills, and recyclability at the end of a long life — that's what we can promise, so that's what we'll say.

## Refills, not replacements

The most overlooked part of a sustainable desk is what happens after the first purchase. A hero object that can't be refilled is just a slower version of disposable. So the pieces meant to be kept are built to be kept going — refilled, topped up, returned to service rather than replaced. It's less glamorous than a launch, but it's the part that actually matters over years. It also, quietly, costs you less.

This is the circular thinking that gives the whole range its shape: one durable centre, surrounded by consumables with a recurring life. You buy the object once and stay in relationship with it.

## Building a desk you won't want to redo

If you're drawn to the analog revival but wary of just buying more stuff, start small and let the system reveal itself.

- **Begin with paper.** A single good notebook you'll actually finish teaches you more about how you work than a stack of empty ones. Browse [Desk & Paper](/collections/desk-and-paper).
- **Add one hero object.** Something that organises the surface and earns its footprint over years, not weeks — see [Objects](/collections/objects).
- **Make the ritual yours.** Focused analog work often comes with a slower pace — a warm drink, a cleared surface. Our [Brew & Sip](/collections/brew-and-sip) and [The Calm Corner](/collections/the-calm-corner) collections lean into that, because the setting is part of the tool.

The aim isn't a perfectly curated desk for a photograph. It's a small set of things, honestly made, that you reach for without thinking — and don't feel the need to replace.

## The quiet case for less

Sustainability, stripped of its slogans, is mostly a question of attention. When you buy something considered, you pay attention to it: where it came from, who made it, how long it will last. That attention is what keeps a thing in use — and a thing kept in use is the whole point.

Buy less, keep longer. It's a smaller way to shop, and a calmer way to work. If that's the kind of desk you're building, start with a single piece from [Desk & Paper](/collections/desk-and-paper) and let the rest come slowly. There's no rush. Good things are meant to be kept.
