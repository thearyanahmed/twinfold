# A calm desk, built from a few good objects

**SEO title:** Sustainable Desk Objects for a Calm Desk | Twinfold
**Meta description:** Pen holders and desk organisers in bio-composite wood, made to earn their place. Build a calm, curated desk system that lasts for years — the Objects collection.
**Primary keywords:** desk organiser, pen holder, sustainable desk objects, calm desk, curated desk system

There's a particular kind of clarity that comes from a tidy desk — not the sterile, showroom kind, but the quiet order of a surface that holds only what you use. A good pen where your hand falls. A single organiser that keeps the small things from drifting. Space to think. If you've felt the pull back toward paper lately — the notebook over the notes app, the pen over the keyboard — you already understand the appeal. The desk is where that intention lives, and it deserves objects that match it.

This is the thinking behind our [Objects](/collections/objects) collection: a small, considered range of pen holders and desk organisers designed to be the calm backbone of a working surface. Not clutter. Not novelty. A few good objects, chosen once and kept for years.

## The case for fewer, better desk objects

The desk has quietly become one of the most cluttered surfaces in the home. Chargers, sticky notes, a mug of pens that no longer write, three organisers doing the job of one. It accumulates the way drawers do — invisibly, until you look up one day and can't find the thing you actually need.

The counter-move isn't another storage solution. It's restraint. A **curated desk system** starts from a simple question: what does this surface genuinely need to hold? For most people who work by hand, the answer is short. Somewhere for the pens you reach for. Somewhere for the small tools and stray objects. Room to spread out a notebook and think.

When each object earns its place, the desk stops being a to-do list and becomes a workspace again. This is the analog logic that's quietly reshaping how people set up to focus in 2026 — fewer screens in the eyeline, more tactile tools within reach, and a surface that feels considered rather than accumulated. A **calm desk** isn't minimalism for its own sake. It's the removal of small daily friction, so the work is the only thing left in front of you.

## Made from bio-composite wood

The objects in this collection are pressed from bio-composite wood — recycled European wood fibres bound with a corn-derived, plant-based polymer, and made in France. It's a material we chose for how it behaves as much as for its provenance.

It has the warmth and weight of wood, not the hollow feel of moulded plastic. The surface is smooth and matte, pleasant under the hand, and it wipes clean — the kind of practical detail that matters on a surface you use every day, where a coffee ring or an inky fingerprint is a question of when, not if. Because the fibres are recycled, each piece carries the quiet honesty of a material with a second life — waste folded back into something worth keeping. It's a small object, but it's made the way we'd want everything on a desk to be made: responsibly, and to last.

## Pen holders that hold their ground

A pen holder is a small thing that shapes a big habit. Keep your good pen upright and within reach, and you'll use it. Bury it in a drawer, and you won't. This is where a desk system usually begins — and where the smallest object does the most work.

The collection offers a few distinct characters, so you can match one to your desk rather than settle:

- The [Japan pen holder](/products/japan-pen-holder) leans into quiet geometry — considered, understated, at home on a spare desk.
- The [Vejle pen holder](/products/vejle-pen-holder) carries a Scandinavian softness, all calm proportion and rounded ease.
- The [Piko pen holder](/products/piko-pen-holder) is the compact one — small-footprint, ideal where space is tight and every centimetre counts.
- The [Stockholm pen holder](/products/stockholm-pen-holder) is the clean, architectural choice for a minimalist desk.
- The [Origami pen holder](/products/origami-pen-holder) brings a folded, sculptural line — a nod, in its form, to the idea of one sheet becoming something more.

None of them shout. That's the point. A pen holder should recede into the desk and let the pen — and the work — do the talking.

## Desk organisers for the small, essential things

Past the pen, the next thing a desk needs is somewhere for everything else: the eraser, the clips, the memory card, the spare cartridge, the small tools that have no obvious home and end up scattered. That's the job of a good **desk organiser** — to gather the loose ends into one honest, tidy place.

The [Brooklyn 01 desk organiser](/products/brooklyn-01-desk-organizer) and its companion, the [Brooklyn 02 desk organiser](/products/brooklyn-02-desk-organizer), are built for exactly this. Compartmented, clean-lined, and made from the same bio-composite wood as the pen holders, they bring a set of small essentials into order without dominating the surface. Choose one for a compact setup, or pair the two to zone a larger desk — writing tools on one side, the everyday small things on the other.

Because they share a material and a visual language with the pen holders, they read as part of one family rather than a collection of unrelated bits. That coherence is what turns a handful of objects into a system — the desk equivalent of a well-edited wardrobe.

## Building a desk you'll keep

The best desks aren't decorated; they're composed. You don't need everything at once. Start with the pen holder that suits how you work, add an organiser when the small things start to wander, and let the surface settle into something that feels genuinely yours. Objects chosen this way don't get replaced every season. They stay — and they get better with use.

That's the whole idea behind Twinfold: a small range of things made well, from materials we can stand behind, built to be lived with rather than churned through. If your desk is where you do your clearest thinking, it's worth furnishing it with the same care.

Take a slow look through the [Objects collection](/collections/objects) and start with one piece that earns its place. The calm desk builds from there.
