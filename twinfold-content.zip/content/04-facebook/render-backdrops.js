const { chromium } = require('playwright');
const fs = require('fs'); const path = require('path');
const outDir = path.join(__dirname,'images'); fs.mkdirSync(outDir,{recursive:true});
const GROUNDS = {
  cream:  { bg:'#FCFBF7', ink:'#2b2c33', accent:'#3f7a50', sub:'#7a7a70' },
  forest: { bg:'#232a24', ink:'#F4F1E8', accent:'#a9bfa6', sub:'#9fa79a' },
  sand:   { bg:'#EAE3D6', ink:'#33342c', accent:'#4a6a4a', sub:'#7c7663' }
};
function html(p){ return `<!doctype html><html><head><meta charset="utf-8">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600&family=Newsreader:opsz,wght@6..72,400&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:1080px;height:1080px}
.w{width:1080px;height:1080px;background:${p.bg};color:${p.ink};display:flex;flex-direction:column;align-items:center;justify-content:center;gap:26px}
.mark{font-family:'Hanken Grotesk',sans-serif;font-weight:600;font-size:76px;letter-spacing:-.01em;text-transform:lowercase}
.rule{width:70px;height:2px;background:${p.accent};opacity:.9}
.tag{font-family:'Hanken Grotesk',sans-serif;font-weight:500;font-size:24px;letter-spacing:.26em;text-transform:uppercase;color:${p.sub}}
</style></head><body><div class="w"><div class="mark">twinfold</div><div class="rule"></div><div class="tag">think on paper</div></div></body></html>`; }
(async()=>{ const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:1080,height:1080},deviceScaleFactor:2});
for(const [name,p] of Object.entries(GROUNDS)){ await pg.setContent(html(p),{waitUntil:'networkidle'}); try{await pg.evaluate(()=>document.fonts.ready)}catch(e){} await pg.waitForTimeout(150); await pg.screenshot({path:path.join(outDir,`backdrop-${name}.png`)}); console.log('rendered backdrop-'+name+'.png'); }
await b.close(); })();
