# Twinfold — 45 Facebook Posts (3/day × 15 days)

_Non-sales, inspiration-led. Suggested UK times: 08:30 · 13:00 · 19:30. Each post pairs with a rotating branded backdrop in `images/` (backdrop-cream / backdrop-forest / backdrop-sand). Paste the post text straight into Facebook; attach the noted backdrop._


---

## Day 1

### 08:30 · Post 1 — The screen-free first hour
*Image: backdrop-forest.png*

> There's a version of the morning that begins before the screen does.
>
> No inbox, no headlines, no one else's plans for your attention — just you, a coffee made slowly, and a page that waits. It sounds like a small thing. It changes the shape of the whole day.
>
> Try it tomorrow: leave the phone charging in another room and give the first hour to your own thoughts.
>
> How do you start your mornings — screen first, or slow?

#analogrevival #screenfree #slowliving #thinkonpaper

### 13:00 · Post 2 — Three things, by hand
*Image: backdrop-cream.png*

> Before the day runs away with you, write down the three things that would make it feel done.
>
> Not the whole list — just three, by hand, where you can see them. There's something about ink that makes a plan feel real in a way a notes app never quite manages.
>
> The rest can wait. Three is enough to begin.
>
> What are your three today?

#thinkonpaper #journaling #mindfuldesk #notebook

### 19:30 · Post 3 — Tidy desk, quiet mind
*Image: backdrop-sand.png*

> A tidy desk is a quiet mind.
>
> At the end of the day, take two minutes to clear the surface — cap the pens, square the notebook, put away what wandered. Leave tomorrow's page open and ready.
>
> You're not just tidying a desk. You're giving tomorrow-you a calmer place to think.
>
> Desk cleared, or desk chaos? Be honest.

#desksetup #calmcorner #quietluxury #slowliving


---

## Day 2

### 08:30 · Post 4 — Paper doesn't ping
*Image: backdrop-cream.png*

> Paper doesn't ping.
>
> It won't interrupt you, autocorrect your half-formed idea, or offer you seventeen other things to look at instead. It just sits there and lets a thought finish itself — which, most days, is exactly what a thought needs.
>
> The screen can wait an hour. The idea can't always.

#papernotpixels #focus #analogrevival #stationery

### 13:00 · Post 5 — Brew it slowly
*Image: backdrop-forest.png*

> The best part of a cup of tea is the part before you drink it.
>
> The kettle settling, the leaves turning slowly in the water, the two or three minutes where there's nothing to do but wait. In a day measured in notifications, that small pause is worth protecting.
>
> Make the next one slowly. Watch it brew.
>
> Tea or coffee for your afternoon reset?

#slowliving #teatime #ritual #mindfuldesk

### 19:30 · Post 6 — Notice one glimmer
*Image: backdrop-cream.png*

> Notice one glimmer today.
>
> Not a milestone — a small, easily-missed moment of quiet joy. The light falling across the desk. The first line written cleanly. The steam off a cup in cold air.
>
> They pass in a second, but if you catch one and hold it, the day feels a little fuller.
>
> What was yours today?

#glimmers #gratitude #slowliving #calm


---

## Day 3

### 08:30 · Post 7 — Phone in another room
*Image: backdrop-forest.png*

> If you change one thing about your mornings, make it this: charge your phone in another room.
>
> The first few days feel strange — a phantom reach toward a bedside table that no longer holds anything. By the end of the week, the quiet stops feeling like absence and starts feeling like room.
>
> You're not banning the phone. You're just not letting it be the first voice you hear.

#screenfree #digitalwellbeing #analogrevival #morningritual

### 13:00 · Post 8 — Slow is not behind
*Image: backdrop-sand.png*

> Slow is not the same as behind.
>
> The considered cup, the handwritten note, the thing made properly — none of them are the inefficient version. They're the version that lasts, and the one you actually remember.
>
> There's no prize for rushing the good part.
>
> Where in your day could you afford to go a little slower?

#slowliving #craft #quietluxury #madetokeep

### 19:30 · Post 9 — Close the day by candlelight
*Image: backdrop-forest.png*

> There's a reason the end-of-day candle has quietly become a ritual for people who stare at screens all day.
>
> Lighting it is a signal: the working part is over. The light drops, the room changes its tone, and you're no longer at your desk so much as beside it.
>
> Close the laptop. Light something. Let the evening be softer than the day.

#calmcorner #candlelight #windingdown #slowliving


---

## Day 4

### 08:30 · Post 10 — Begin with your own thoughts
*Image: backdrop-cream.png*

> Begin the day with your own thoughts, before the world hands you a thousand of its own.
>
> Most mornings we wake straight into other people's urgencies. But the first few minutes, met quietly, set the emotional weather for everything that follows.
>
> A page, a pen, a slow breath. Arrive in your day on your own terms.

#morningritual #mindfulness #screenfree #analogrevival

### 13:00 · Post 11 — One pen, within reach
*Image: backdrop-sand.png*

> A good pen kept within reach is a small thing that shapes a big habit.
>
> Leave it upright on the desk and you'll use it a dozen times a day. Bury it in a drawer and you won't touch it for a week. The tools we reach for are simply the ones we can see.
>
> Keep the good one out. Let it earn its place.

#desksetup #deskobjects #stationerylove #thinkonpaper

### 19:30 · Post 12 — Something green, nearby
*Image: backdrop-forest.png*

> Every calm desk seems to have something green nearby.
>
> A small plant gives the eye somewhere to rest between tasks, marks the slow passing of days, and asks for a tiny ritual — a splash of water, a turn toward the light. That little bit of tending is a screen-free pause built into your week.
>
> What's on your desk right now?

#calmcorner #deskplants #slowliving #mindfuldesk


---

## Day 5

### 08:30 · Post 13 — Write to think
*Image: backdrop-cream.png*

> You don't write things down to remember them. You write them down to find out what you actually think.
>
> Handwriting is slower than typing, and that slowness is the point — it makes you choose your words, and in choosing them, you work out what you mean.
>
> Next time your head feels crowded, don't open an app. Open a notebook.

#journaling #thinkonpaper #focus #notebook

### 13:00 · Post 14 — Finish one notebook
*Image: backdrop-sand.png*

> A single notebook you actually finish will teach you more than a shelf of empty ones.
>
> There's a quiet satisfaction in filling one from first page to last — watching a project, a season, a train of thought accumulate in your own hand.
>
> Start on page one. Don't save it for something special. This is the something special.
>
> Are you a finisher, or a collector of half-used notebooks?

#notebook #stationery #journaling #madetokeep

### 19:30 · Post 15 — Let the week settle
*Image: backdrop-forest.png*

> Let the week settle.
>
> Friday evening doesn't need a plan. Make something warm, clear the desk without urgency, close the notebook on the week that was. The work will still be there on Monday, and it'll keep.
>
> For now, slow down. You've earned the quiet.
>
> How are you closing your week?

#slowliving #friday #teatime #calm


---

## Day 6

### 08:30 · Post 16 — Nowhere to rush
*Image: backdrop-cream.png*

> There's nowhere you have to rush this morning.
>
> A slower Saturday: coffee made properly, a real book, the phone face-down on the far side of the room. No feed to catch up on, no urgency borrowed from someone else's day.
>
> Protect it. The weekend disappears fastest through a screen.

#slowweekend #slowliving #screenfree #analogrevival

### 13:00 · Post 17 — Keep, don't replace
*Image: backdrop-sand.png*

> Buy less. Keep longer.
>
> A notebook you use for a year, a pen you refill instead of replace, one good object kept for a decade — each leaves a far smaller mark than a drawer of cheaper things bought and binned.
>
> The most sustainable thing you own is usually the thing you already have, still in use.
>
> What's the oldest thing on your desk?

#buylesskeeplonger #sustainable #madetokeep #quietluxury

### 19:30 · Post 18 — Boredom makes ideas
*Image: backdrop-forest.png*

> A little boredom is where ideas come from.
>
> We've trained ourselves to fill every gap — a queue, a kettle, a quiet minute — with a screen. But the mind only wanders somewhere interesting when you let it wander at all.
>
> Tonight, put nothing on. Stare out of the window. See what turns up.

#slowliving #creativity #screenfree #calm


---

## Day 7

### 08:30 · Post 19 — Sunlight before screens
*Image: backdrop-cream.png*

> Sunlight before screens.
>
> Two minutes at the window, or a slow step outside with your coffee, does more for your energy than any notification ever will. Morning light tells your body the day has begun — gently, and on your terms.
>
> Before you reach for the phone, reach for the daylight.

#morningritual #screenfree #slowliving #wellbeing

### 13:00 · Post 20 — Write one letter
*Image: backdrop-sand.png*

> When did you last write someone an actual letter?
>
> A few lines in your own hand land differently from a message — slower, warmer, kept. Someone you know would love to find one on the doormat instead of another bill.
>
> It takes ten minutes and a stamp. Small effort, disproportionate joy.
>
> Who would you write to?

#letterwriting #stationerylove #slowliving #notecards

### 19:30 · Post 21 — Set the week on paper
*Image: backdrop-forest.png*

> Before Monday arrives, set the shape of the week on paper.
>
> Not every task — just the handful that matter, written where you can see them. There's a calm that comes from closing Sunday with a plan you can hold in your hand rather than scattered across five apps.
>
> Screens can wait till morning. Tonight, just the page.

#planning #thinkonpaper #mindfuldesk #analogrevival


---

## Day 8

### 08:30 · Post 22 — One thing, fully
*Image: backdrop-cream.png*

> One thing, fully.
>
> Not five tabs and a half-watched video — one task, one page, one pen, for a stretch of uninterrupted time. Depth is quieter than multitasking, and far more satisfying.
>
> Pick the one thing that matters most today and give it your whole attention first.
>
> What's your one thing?

#deepwork #focus #thinkonpaper #mindfuldesk

### 13:00 · Post 23 — A break made with your hands
*Image: backdrop-forest.png*

> Some breaks are better made with your hands.
>
> Whisking matcha, warming a pot, waiting for the bloom on a pour-over — a small ceremony that asks for two or three minutes of full attention and gives back a clear head.
>
> A proper pause isn't a smaller screen. It's no screen at all.
>
> What's your midday ritual?

#matcha #teatime #ritual #slowliving

### 19:30 · Post 24 — Where you sit matters
*Image: backdrop-sand.png*

> Where you sit matters more than any productivity trick.
>
> A corner by a window, something green within reach, candlelight to close the day — the space around your work quietly shapes how the work goes. Attention is environmental.
>
> You don't need a whole room. A calm corner will do.
>
> Show us your corner, if you like.

#calmcorner #desksetup #slowliving #quietluxury


---

## Day 9

### 08:30 · Post 25 — Intention over perfection
*Image: backdrop-forest.png*

> Intention over perfection.
>
> The morning doesn't need to look like the ones online — no perfect flat-lay, no five-step routine. It just needs to be yours for a little while before the day asks for everything.
>
> One quiet cup, one honest page. That's a good morning.

#morningritual #mindfulness #slowliving #analogrevival

### 13:00 · Post 26 — A home for the small things
*Image: backdrop-cream.png*

> Give the small things a home and the whole desk goes quiet.
>
> The clips, the spare cartridge, the little tools that drift across the surface — gather them into one place and suddenly there's room to think again. Clutter is mostly just things without a home.
>
> One small tidy. Big difference.
>
> What's cluttering your desk right now?

#deskobjects #desksetup #organised #mindfuldesk

### 19:30 · Post 27 — The last page of the day
*Image: backdrop-sand.png*

> End the day on the last page.
>
> A line or two before bed — what happened, what you're grateful for, what can wait until tomorrow. Getting it out of your head and onto paper is one of the simplest ways to sleep a little easier.
>
> Close the notebook. Rest.
>
> Do you journal at night, or is that a new idea?

#journaling #gratitude #eveningritual #slowliving


---

## Day 10

### 08:30 · Post 28 — Ink remembers
*Image: backdrop-forest.png*

> Ink remembers better than pixels.
>
> Write something down by hand and you're far more likely to recall it — not because paper is magic, but because handwriting makes you slow down and choose. The choosing is what makes it stick.
>
> The note you'll actually remember is the one you wrote yourself.

#thinkonpaper #journaling #notebook #focus

### 13:00 · Post 29 — Leave the phone at lunch
*Image: backdrop-cream.png*

> Try eating lunch without your phone.
>
> No scrolling, no half-watching — just the food, and maybe a window to look out of. It feels oddly long the first time, and then it feels like a genuine break.
>
> A small rebellion, and a real rest.
>
> Could you do one screen-free meal today?

#screenfree #digitalwellbeing #slowliving #mindfulness

### 19:30 · Post 30 — The day's small pleasures
*Image: backdrop-sand.png*

> Steam off a cup. Late light across the desk. A page filled in your own hand.
>
> The day's real pleasures are mostly the quiet ones — easy to walk past, easy to keep if you slow down enough to notice.
>
> Before this one ends, collect a couple.
>
> What small thing made today better?

#glimmers #slowliving #gratitude #calm


---

## Day 11

### 08:30 · Post 31 — A calm desk thinks better
*Image: backdrop-forest.png*

> A calm desk thinks better.
>
> Clear the edges, lower the noise, put the phone out of eyeline, and the work suddenly has room to arrive. You can't always control the day — but you can control the small patch of it you meet the day from.
>
> Start by taking one thing off the desk that doesn't belong there.

#desksetup #focus #calmcorner #mindfuldesk

### 13:00 · Post 32 — Make the cup with care
*Image: backdrop-cream.png*

> Make the cup with care and the hour tends to follow.
>
> The pour, the wait, the leaves turning slowly in clear water — a few unhurried minutes that reset your attention before the afternoon. It's not really about the drink. It's about the pause around it.
>
> Slow down for one cup today. See what it does.

#teatime #slowliving #ritual #mindfuldesk

### 19:30 · Post 33 — No two alike
*Image: backdrop-sand.png*

> No two are quite alike.
>
> There's a particular pleasure in an object made by hand — a reactive glaze that pooled its own way in the kiln, a mark that belongs to yours and no one else's. Perfectly identical is easy to make and easy to forget.
>
> The things we keep longest are usually the ones with a little character.

#handmade #calmcorner #quietluxury #madetokeep


---

## Day 12

### 08:30 · Post 34 — Fewer things, chosen well
*Image: backdrop-forest.png*

> Fewer things, chosen well.
>
> Three beautiful, durable things you reach for every day will always beat a drawer full of forgettable ones. It's calmer to own, kinder to make, and — quietly — cheaper over time.
>
> That's the whole idea: keep less, but keep better.
>
> What's one thing you'd never replace?

#buylesskeeplonger #quietluxury #sustainable #considered

### 13:00 · Post 35 — Catch the idea
*Image: backdrop-cream.png*

> Catch the idea before it goes.
>
> The good ones never arrive at the desk — they turn up on a walk, in a queue, halfway through the washing up. A small notebook or a single card in your pocket is where they actually get saved.
>
> Write it down now. You won't remember it later. You never do.

#notebook #thinkonpaper #stationerylove #ideas

### 19:30 · Post 36 — Wind down, unplugged
*Image: backdrop-sand.png*

> Wind down, unplugged.
>
> Dim the screens an hour before bed and let the evening turn analog — a few pages of a real book, a candle, a slow last cup. Your eyes settle, your mind slows, and sleep comes easier.
>
> The day's last hour doesn't have to glow.
>
> What's your evening wind-down?

#screenfree #eveningritual #slowliving #calm


---

## Day 13

### 08:30 · Post 37 — Begin before you're reachable
*Image: backdrop-forest.png*

> Begin before you're reachable.
>
> Give yourself the first stretch of the day before the messages start — thoughts thought, a page written, coffee actually tasted. Being available to everyone all the time is a choice, and mornings are a fine place to opt out of it.
>
> The world will find you at nine. Until then, you're off the clock.

#morningritual #screenfree #analogrevival #focus

### 13:00 · Post 38 — Clear to the essentials
*Image: backdrop-cream.png*

> Clear the desk down to the essentials.
>
> Ask what this surface genuinely needs to hold, and the answer is usually less than what's on it. A pen you love, the notebook you're in, one thing that's alive. The rest can live in a drawer.
>
> Take one thing off right now. Notice how it feels.

#desksetup #minimalism #mindfuldesk #calmcorner

### 19:30 · Post 39 — The quiet is the point
*Image: backdrop-sand.png*

> The quiet is the point.
>
> Not every hour needs a soundtrack or a second screen. A little stillness in the evening isn't emptiness — it's where the day catches up with you and the better thoughts finally surface.
>
> Tonight, try a few minutes with nothing on at all.

#slowliving #calm #mindfulness #screenfree


---

## Day 14

### 08:30 · Post 40 — A blank page is room
*Image: backdrop-forest.png*

> A blank page is not empty. It's room.
>
> Space to think is the rarest thing a working day offers — and the easiest to create. One clear page, no notifications, a few unclaimed minutes. That's all a good idea needs to show up.
>
> Give yourself the room this morning.

#thinkonpaper #journaling #focus #notebook

### 13:00 · Post 41 — Step away, then return
*Image: backdrop-cream.png*

> Step away. Then come back.
>
> The best breaks aren't a smaller screen — they're no screen at all. Make tea, stand at the window, stretch your legs for five minutes. You'll return to the work clearer than if you'd pushed straight through.
>
> When did you last take a proper break?

#slowliving #screenfree #teatime #wellbeing

### 19:30 · Post 42 — A little green, a little warmth
*Image: backdrop-sand.png*

> A little green, a little warmth.
>
> A plant by the window, a candle for the evening, a corner cleared of clutter — the small setting that makes focus possible in the first place. You tend the space, and the space tends you back.
>
> One plant, one candle. A calm corner starts there.

#calmcorner #desksetup #slowliving #quietluxury


---

## Day 15

### 08:30 · Post 43 — Think better on paper
*Image: backdrop-forest.png*

> Think better on paper.
>
> The whole idea, in four words. Not anti-screen, not anti-progress — just a quiet reminder that some of your best thinking happens with a pen in your hand and nothing blinking for your attention.
>
> However you start today, start it slowly.
>
> Paper or screen for your ideas?

#thinkonpaper #analogrevival #slowliving #stationery

### 13:00 · Post 44 — Keep what lasts
*Image: backdrop-cream.png*

> At the end of two weeks of slower mornings, notice what you kept reaching for.
>
> The one notebook. The pen that feels right. The cup you always choose. Those few, well-used things are the keepers — the small system that quietly makes the rest work.
>
> Everything else is just noise on the desk.
>
> What made your shortlist?

#buylesskeeplonger #madetokeep #considered #quietluxury

### 19:30 · Post 45 — Two leaves, one fold
*Image: backdrop-sand.png*

> Two leaves from one fold.
>
> It's where our name comes from — one origin, two lives, waste folded back into something worth keeping. A calmer way to work, and a kinder way to keep the things we work with.
>
> Thank you for spending a slower fifteen days with us. The page is always open.
>
> Here's to thinking on paper.

#twinfold #sustainable #slowliving #madetokeep

